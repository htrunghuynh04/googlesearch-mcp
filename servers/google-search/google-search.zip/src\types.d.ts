/**
 * 搜索结果接口
 */
export interface SearchResult {
    title: string;
    link: string;
    snippet: string;
}
/**
 * Web搜索结果接口（带排名位置）
 */
export interface WebSearchResult {
    rank: number;
    title: string;
    url: string;
    snippet: string;
}
/**
 * 页面内容接口
 */
export interface WebPageContent {
    page_title: string;
    url: string;
    headings: HeadingStructure;
    content: string;
}
/**
 * 标题结构接口
 */
export interface HeadingStructure {
    H1: string[];
    H2: string[];
    H3: string[];
}
/**
 * 搜索响应接口
 */
export interface SearchResponse {
    query: string;
    results: SearchResult[];
}
/**
 * 命令行选项接口
 */
export interface CommandOptions {
    limit?: number;
    timeout?: number;
    headless?: boolean;
    stateFile?: string;
    noSaveState?: boolean;
    locale?: string;
}
/**
 * HTML响应接口 - 用于获取原始搜索页面HTML
 */
export interface HtmlResponse {
    query: string;
    html: string;
    url: string;
    savedPath?: string;
    screenshotPath?: string;
    originalHtmlLength?: number;
}
