import { Browser } from "playwright";
import { SearchResponse, SearchResult, CommandOptions, HtmlResponse, WebSearchResult, WebPageContent, HeadingStructure } from "./types.js";
/**
 * Execute Google search and return results
 * @param query Search keyword
 * @param options Search options
 * @returns Search results
 */
export declare function googleSearch(query: string, options?: CommandOptions, existingBrowser?: Browser): Promise<SearchResponse>;
/**
 * Get raw HTML of Google search results page
 * @param query Search keyword
 * @param options Search options
 * @param saveToFile Whether to save HTML to file (optional)
 * @param outputPath HTML output file path (optional, default'./google-search-html/[query]-[timestamp].html'）
 * @returns Response object containing HTML content
 */
export declare function getGoogleSearchPageHtml(query: string, options?: CommandOptions, saveToFile?: boolean, outputPath?: string): Promise<HtmlResponse>;
/**
 * Extract heading structure from HTML (H1, H2, H3)
 * @param html Page HTML content
 * @returns Heading structure object
 */
export declare function extractHeadings(html: string): HeadingStructure;
/**
 * Get webpage content and heading structure
 * @param url Webpage URL
 * @param browser Optional Playwright browser instance
 * @returns Object containing page title, heading structure and content
 */
export declare function fetchWebpage(url: string, browser?: Browser): Promise<WebPageContent>;
/**
 * Convert search results to WebSearchResult format (with ranking)
 * @param results Raw search results
 * @param limit Result count limit
 * @returns Search results with ranking
 */
export declare function formatWebSearchResults(results: SearchResult[], limit?: number): WebSearchResult[];
